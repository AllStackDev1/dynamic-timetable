<?php 
include_once('_general_func_.php');

class ClassFunction extends Academic_MainClass{
 
    private $username;
    private $userpass;

    function __construct($username,$szpassword){
        
        $this->username = $username;
        $this->userpass = $szpassword;
        
        parent::__construct($username,$szpassword);
        parent::set_dbuserName($username);
        parent::set_dbpassword($szpassword);
        
       // parent::set_App('Academic');
    }

    function AddData($sz_period,$sz_dayid,$sz_teacherid,$sz_per_allo,$sz_classid,$sz_branchid,$sz_schoolid){
    
        $count = count($sz_dayid);
        $sz_dayidArrtoStr = implode("','", $sz_dayid);
        //this defines the connection to the database.
        $db = new Mysqli('localhost', 'root', '', 'ikolilu_a');
        $SQL =  mysqli_query($db,"SELECT * FROM `acc_timetable` WHERE sz_period = '$sz_period' AND sz_classid = '$sz_classid' AND sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid'  AND sz_dayid IN('$sz_dayidArrtoStr')");
                //Check to see if a period has already been allocated to some thing on that particular day 
                if (mysqli_num_rows($SQL) > 0) {
                    return -1;
                }elseif (!isset($sz_period)) {
                        return -1;
                }else{
                    if ($sz_teacherid == 0) {
                        $SQL =  mysqli_query($db,"SELECT `sz_periodid` FROM `acc_periods` WHERE sz_period = '$sz_period' AND sz_classid = '$sz_classid' AND sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid'");
                        $query = mysqli_fetch_array($SQL);
                        $sz_periodid = $query['sz_periodid'];
                        //this defines the connection to the database.
                            $db = new connection($this->username,$this->userpass);
                            //create an instance of the connection to the database.
                            $conn = $db->mysql_conn();
                            $strSQL[0] = "INSERT INTO `acc_timetable`(`id`, `sz_period`, `sz_periodid`, `sz_per_allo`, `sz_dayid`, `sz_classid`, `sz_branchid`, `sz_schoolid`) VALUES"; 
                            for($i = 0; $i < $count; $i++) {
                                $strSQL[0] .= "('','$sz_period','$sz_periodid','$sz_per_allo','$sz_dayid[$i]','$sz_classid','$sz_branchid','$sz_schoolid')";
                                if($i < ($count -1 )){
                                    $strSQL[0] .=",";
                                }
                            }
                            $retval = $db->RunSQLWithTrans($strSQL);   
                            return $retval;
                            
                    }else{
                        $SQL =  mysqli_query($db,"SELECT * FROM `acc_timetable` WHERE sz_period = '$sz_period' AND sz_teacherid = '$sz_teacherid' AND sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid' AND sz_dayid IN('$sz_dayidArrtoStr')");
                        //Check to see if a teacher has already been allocated to a class on that particular period of the day 
                        if (mysqli_num_rows($SQL) > 0) {
                            return -2;
                        }else{
                            $SQL =  mysqli_query($db,"SELECT `sz_periodid` FROM `acc_periods` WHERE sz_period = '$sz_period' AND sz_classid = '$sz_classid' AND sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid'");
                            $query = mysqli_fetch_array($SQL);
                            $sz_periodid = $query['sz_periodid'];
                                //this defines the connection to the database.
                                $db = new connection($this->username,$this->userpass);
                                //create an instance of the connection to the database.
                                $conn = $db->mysql_conn();
                                $strSQL[0] = "INSERT INTO `acc_timetable`(`id`, `sz_period`, `sz_periodid`, `sz_per_allo`, `sz_dayid`, `sz_classid`, `sz_branchid`, `sz_schoolid`) VALUES"; 

                                for($i = 0; $i < $count; $i++) {
                                    $strSQL[0] .= "('','$sz_period','$sz_periodid','$sz_per_allo','$sz_dayid[$i]','$sz_classid','$sz_branchid','$sz_schoolid')";
                                    if($i < ($count -1 )){
                                        $strSQL[0] .=",";
                                    }
                                }
                                $retval = $db->RunSQLWithTrans($strSQL);   
                                return $retval;
                        }    
                    }                    
                }

    }

    function DeletePeriod($sz_periodid="",$sz_classid="",$sz_branchid="",$sz_schoolid=""){

        //this defines the connection to the database.
        $db = new connection($this->username,$this->userpass);
        //create an instance of the connection to the database.
        $conn = $db->mysql_conn();
        $strSQL[0] = "DELETE FROM `acc_timetable` WHERE sz_periodid = '$sz_periodid' AND sz_classid = '$sz_classid' AND sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid'";
        $retval = $db->RunSQLWithTrans($strSQL);
        return $retval;
    }

    function DeleteDayPeriod($sz_periodid="",$sz_dayid="",$sz_classid="",$sz_branchid="",$sz_schoolid=""){

        //this defines the connection to the database.
        $db = new connection($this->username,$this->userpass);
        //create an instance of the connection to the database.
        $conn = $db->mysql_conn();
        $strSQL[0] = "DELETE FROM `acc_timetable` WHERE sz_periodid = '$sz_periodid' AND sz_classid = '$sz_classid' AND sz_dayid = '$sz_dayid' AND sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid'";
        $retval = $db->RunSQLWithTrans($strSQL);
        return $retval;
    }

    function DropPeriods($sz_classid="",$sz_branchid="",$sz_schoolid=""){
        //this defines the connection to the database.
        $db = new connection($this->username,$this->userpass);
        //create an instance of the connection to the database.
        $conn = $db->mysql_conn();
        $strSQL[0] = "DELETE FROM `acc_periods` WHERE sz_classid = '$sz_classid' AND sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid'";
        $retval = $db->RunSQLWithTrans($strSQL);
        return $retval;
    }

    function DropTimeTable($sz_classid="",$sz_branchid="",$sz_schoolid=""){
        //this defines the connection to the database.
        $db = new connection($this->username,$this->userpass);
        //create an instance of the connection to the database.
        $conn = $db->mysql_conn();
        $strSQL[0] = "DELETE FROM `acc_timetable` WHERE sz_classid = '$sz_classid' AND sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid'";
        $retval = $db->RunSQLWithTrans($strSQL);
        return $retval;
    }

    function GetAllData($sz_branchid,$sz_schoolid){
        //this defines the connection to the database.
        $db = new connection($this->username,$this->userpass);
        //create an instance of the connection to the database.
        $conn = $db->mysql_conn();
        $strSQL = "SELECT * FROM `acc_timetable` WHERE sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid'";
        //$conn->debug=true;
        $rs = $conn->Execute($strSQL);
        if($rs){
           $sys_info = $rs->GetArray();
        }
        return @$sys_info;  
    }

    function  GetData($sz_classid,$sz_branchid,$sz_schoolid){
        //this defines the connection to the database.
        $db = new connection($this->username,$this->userpass);
        //create an instance of the connection to the database.
        $conn = $db->mysql_conn();
        $strSQL = "SELECT * FROM `acc_timetable` WHERE sz_classid = '$sz_classid' AND sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid'";
        $rs = $conn->Execute($strSQL); 
        if($rs){
            $sys_details = $rs->GetArray();
        }
        return $sys_details;  
    }
   
    function UpdateData($sz_period,$sz_dayid,$sz_teacherid,$sz_per_allo,$sz_classid,$sz_branchid,$sz_schoolid){
        //this defines the connection to the database.
        $db = new connection($this->username,$this->userpass);
        //create an instance of the connection to the database.
        $conn = $db->mysql_conn();
        $strSQL[0] = " UPDATE `acc_timetable` SET `sz_per_allo`='$sz_per_allo',`sz_teacherid`='$sz_teacherid' WHERE sz_classid = '$sz_classid' AND sz_branchid = '$sz_branchid' AND sz_schoolid = '$sz_schoolid' AND sz_period = '$sz_period' AND sz_dayid = '$sz_dayid'";
        $retval = $db->RunSQLWithTrans($strSQL);     
         return $retval;            
    }
}

?>