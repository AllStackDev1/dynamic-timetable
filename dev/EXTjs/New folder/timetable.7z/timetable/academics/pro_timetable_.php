<?php
session_start();

 include_once('Lib/connect.php');
 include_once("includes/function_timetable_.php");
 
 $_SESSION['org'] = 'GSISSCHOOL';
 $_SESSION['userid'] = 'Nedu';
 $_SESSION["username"] = '';
 $_SESSION["password"] = '';

$c_user = isset($_SESSION["userid"]) ? $_SESSION["userid"] : false;	   
if(!$c_user) 
{
     session_destroy();
     ob_start();
     header("Location: ../eUserLog/index.html");
     ob_flush();
}


 $btn = isset($_REQUEST["btn"]) ? $_REQUEST["btn"] : false;	 
   
 if(!$btn) 
 {
     echo '{"success":false,"error":"No command"}';
     exit;
 }	
 
 //$main = new setup($_SESSION["username"],$_SESSION["profile"]);
 $db = new connection($_SESSION["username"],$_SESSION["password"]);
 $func = new ClassFunction($_SESSION["username"],$_SESSION["password"]);
 

 if($btn == "Load")
 {
 	//id,subject_id,subject_name,teacher_id,teacher_name,period_id,sequence,per_day,duration,day,sz_branchid,sz_schoolid

		 $fields[0] 	= 'id';
		 $fields[1] 	= 'sz_period';
		 $fields[2] 	= 'sz_periodid';
		 $fields[3] 	= 'sz_per_allo';
	     $fields[4] 	= 'sz_teacherid';
	     $fields[5] 	= 'sz_dayid';
	     $fields[6] 	= 'sz_classid';
	     $fields[7] 	= 'sz_branchid';
	     $fields[8] 	= 'sz_schoolid';


		 // Check for an existing row...
		 
		 $records = $func->GetAllData();
		 $retval = $db->RunCodeReturnJson($fields,$records);
		echo $retval;

}else 
 
if($btn == "Save"){

		$sz_period 		= $_REQUEST['sz_period'];
		$sz_dayid	 	= $_REQUEST['sz_dayid'];
		$sz_teacherid	= $_REQUEST['sz_teacherid'];
		$sz_per_allo	= $_REQUEST['sz_per_allo'];
		$sz_classid  	= $_REQUEST['sz_classid'];
		$sz_schoolid 	= $_REQUEST['sz_schoolid'];
		$sz_branchid 	= $_REQUEST['sz_branchid'];

		$add = $func->AddData($sz_period,$sz_dayid,$sz_teacherid,$sz_per_allo,$sz_classid,$sz_branchid,$sz_schoolid);
		 if($add == 1)
		  {
		    echo "{success: true,errors:{reason:'Data Successfully Saved.'}}";
		    echo '<script type="text/javascript">
    				window.location = "../period_setting.php"
          		  </script>';
			
		  }else
		  {
		    echo "{success: false,errors:{reason:'Period Already Allocated'}}";
		  }

 }else 
    if($btn == "Edit"){
	
	 $id   = $_REQUEST['id'];
         $res = $func->GetData($id);
	
	 if(count($res) > 0)
     {
 	    //id,subject_id,subject_name,teacher_id,teacher_name,period_id,day,sz_schoolid,sz_schoolid
		$param[0] = 'id';
		$param[1] = 'subject_id';
		$param[2] = 'subject_name';
		$param[3] = 'teacher_id';
		$param[4] = 'teacher_name';
	    $param[5] = 'period_id';
	    $param[6] = 'day';
	    $param[7] = 'sz_schoolid';
		$param[8] = 'sz_schoolid';
		
		$retval = $db->RunCodeReturnJsonRC($param,$res);
		echo $retval;
	 }else
	 {
	       echo "{success: false,errors:{reason:'No Record Found..'}}";
     }   
			 
	}else
	   if($btn == "Delete"){

		   	$sz_periodid  = $_REQUEST['sz_periodid'];
		   	$sz_dayid	  = $_REQUEST['sz_dayid'];
		    $sz_classid   = $_REQUEST['sz_classid'];
		    $sz_branchid  = $_REQUEST['sz_branchid'];
		    $sz_schoolid  = $_REQUEST['sz_schoolid'];


	   	if ($sz_dayid == 0) {

	   		$delete = $func->DeletePeriod($sz_periodid,$sz_classid,$sz_branchid,$sz_schoolid);
	 
		    if($delete > 0) {
		    	echo "{success: true,errors:{reason:'Data Succesfully Deleted.'}}";
			
		    }else{
			    echo "{success: false,errors:{reason:'Error While Deleting Data'}}";
			}
	   			
	   	}else{

	   		$delete = $func->DeleteDayPeriod($sz_periodid,$sz_dayid,$sz_classid,$sz_branchid,$sz_schoolid);
	 
		    if($delete > 0) {
		    	echo "{success: true,errors:{reason:'Data Succesfully Deleted.'}}";
			
		    }else{
			    echo "{success: false,errors:{reason:'Error While Deleting Data'}}";
			}
	   	}
}else
	if($btn == "DropPeriods"){
		$sz_classid   = $_REQUEST['sz_classid'];
		$sz_branchid  = $_REQUEST['sz_branchid'];
		$sz_schoolid  = $_REQUEST['sz_schoolid'];

		$drop = $func->DropPeriods($sz_classid,$sz_branchid,$sz_schoolid);
		 
		if($drop > 0) {
			echo "{success: true,errors:{reason:'Data Succesfully Dropped.'}}";
				
		}else{
			echo "{success: false,errors:{reason:'Error While Dropping Data'}}";
		}	   		
}else
	if($btn == "DropTimeTable"){
		
		$sz_classid   = $_REQUEST['sz_classid'];
		$sz_branchid  = $_REQUEST['sz_branchid'];
		$sz_schoolid  = $_REQUEST['sz_schoolid'];

		$drop = $func->DropTimeTable($sz_classid,$sz_branchid,$sz_schoolid);
		 
		if($drop > 0) {
			echo "{success: true,errors:{reason:'Data Succesfully Dropped.'}}";
				
		}else{
			echo "{success: false,errors:{reason:'Error While Dropping Data'}}";
		}
}else
	if($btn == "Update"){

		$sz_period 		= $_REQUEST['sz_period'];
		$sz_dayid	 	= $_REQUEST['sz_dayid'];
		$sz_teacherid	= $_REQUEST['sz_teacherid'];
		$sz_per_allo	= $_REQUEST['sz_per_allo'];
		$sz_classid  	= $_REQUEST['sz_classid'];
		$sz_schoolid 	= $_REQUEST['sz_schoolid'];
		$sz_branchid 	= $_REQUEST['sz_branchid'];

		$update = $func->UpdateData($sz_period,$sz_dayid,$sz_teacherid,$sz_per_allo,$sz_classid,$sz_branchid,$sz_schoolid);
		 
	    if($update == 1){
	    	echo "{success: true,errors:{reason:'Data Succesfully Updated.'}}";
	  	}else{
	    	echo "{success: false,errors:{reason:'Error While Updating Data'}}";
		}

}

?>
