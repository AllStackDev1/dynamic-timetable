-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2018 at 06:35 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ikolilu_b`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc_subjects`
--

CREATE TABLE `acc_subjects` (
  `id` int(11) NOT NULL,
  `subject_name` varchar(30) NOT NULL,
  `subject_id` varchar(11) NOT NULL,
  `teacher_id` varchar(30) NOT NULL,
  `teacher_name` varchar(30) NOT NULL,
  `class_id` varchar(11) NOT NULL,
  `szbranch_id` varchar(11) NOT NULL,
  `szschool_id` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acc_subjects`
--

INSERT INTO `acc_subjects` (`id`, `subject_name`, `subject_id`, `teacher_id`, `teacher_name`, `class_id`, `szbranch_id`, `szschool_id`) VALUES
(1, 'English', '00001', 'PF0001', 'Jane Nana-osei', 'pri1', 'gg1000zde', 'gg1000'),
(2, 'Mathematic', '00002', 'PF0002', 'John Mensa', 'pri1', 'gg1000zde', 'gg1000'),
(3, 'Info Tech', '00003', 'PF0003', 'James Nonso', 'pri1', 'gg1000zde', 'gg1000'),
(4, 'Religious Studies', '00004', 'PF0004', 'Pst. John', 'pri1', 'gg1000zde', 'gg1000'),
(5, 'Physics', '00005', 'PF0005', 'James Nonso', 'pri1', 'gg1000zde', 'gg1000'),
(6, 'Geography', '00006', 'PF0006', 'Pst. John', 'pri1', 'gg1000zde', 'gg1000'),
(7, 'Economics', '00007', 'PF0007', 'Peter Nonso', 'pri1', 'gg1000zde', 'gg1000'),
(8, 'Chemistry', '00008', 'PF0008', 'Mr John', 'pri1', 'gg1000zde', 'gg1000'),
(9, 'History', '00009', 'PF0009', 'Chinedu', 'pri1', 'gg1000zde', 'gg1000'),
(10, 'Biology', '00010', 'PF0010', 'Grace', 'pri1', 'gg1000zde', 'gg1000'),
(11, 'Government ', '00011', 'PF0011', 'Mary', 'pri1', 'gg1000zde', 'gg1000');

-- --------------------------------------------------------

--
-- Table structure for table `acc_timetable`
--

CREATE TABLE `acc_timetable` (
  `id` int(11) NOT NULL,
  `subject_id` varchar(20) NOT NULL,
  `subject_name` varchar(20) NOT NULL,
  `teacher_id` varchar(11) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `start_time` varchar(11) NOT NULL,
  `end_time` varchar(11) NOT NULL,
  `period_id` varchar(11) NOT NULL,
  `class_id` varchar(200) NOT NULL,
  `day` varchar(200) NOT NULL,
  `szbranch_id` varchar(200) NOT NULL,
  `szschool_id` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acc_timetable`
--

INSERT INTO `acc_timetable` (`id`, `subject_id`, `subject_name`, `teacher_id`, `teacher_name`, `start_time`, `end_time`, `period_id`, `class_id`, `day`, `szbranch_id`, `szschool_id`) VALUES
(24, '00008', 'Chemistry', 'PF0008', 'Mr John', '7:00', '7:30', '1', 'jss1', 'monday', 'gg1000wyz', 'gg1000'),
(25, '00001', 'English', 'PF0001', 'Jane Nana-osei', '7:30', '8:00', '2', 'jss1', 'monday', 'gg1000wyz', 'gg1000'),
(43, '00010', 'Biology', 'PF0010', 'Grace', '8:00', '8:30', '3', 'jss1', 'monday', 'gg1000wyz', 'gg1000'),
(47, '00002', 'Mathematic ', 'PF0002', 'John Mensa', '8:30', '9:00', '4', 'jss1', 'monday', 'gg1000wyz', 'gg1000'),
(48, '00002', 'Mathematic', 'PF0002', 'John Mensa', '9:30', '10:00', '5', 'jss1', 'monday', 'gg1000wyz', 'gg1000'),
(49, '00005', 'Physics', 'PF0005', 'James Nonso', '10:00', '10:30', '6', 'jss1', 'monday', 'gg1000wyz', 'gg1000'),
(70, '00006', 'Geography', 'PF0008', 'Mr John', '10:30', '11:00', '7', 'jss1', 'monday', 'gg1000wyz', 'gg1000'),
(114, '00007', 'Economics', 'PF0007', 'Peter Nonso', '11:10', '11:40', '8', 'jss1', 'monday', 'gg1000wyz', 'gg1000'),
(115, '00003', 'Info Tech', 'PF0003', 'James Nonso', '7:30', '8:10', '1', 'pri1', 'tuesday', 'gg1000zde', 'gg1000'),
(116, '00001', 'English ', 'PF0001', 'Jane Nana-osei', '8:10', '8:50', '2', 'pri1', 'tuesday', 'gg1000zde', 'gg1000'),
(117, '00001', 'English', 'PF0001', 'Jane Nana-osei', '8:50', '9:30', '3', 'pri1', 'tuesday', 'gg1000zde', 'gg1000'),
(118, '00010', 'Biology ', 'PF0010', 'Grace', '10:00', '10:40', '4', 'pri1', 'tuesday', 'gg1000zde', 'gg1000'),
(119, '00002', 'Mathematic', 'PF0002', 'John Mensa', '10:40', '11:20', '5', 'pri1', 'tuesday', 'gg1000zde', 'gg1000'),
(120, '00004', 'Religious Studies', 'PF0004', 'Pst. John', '11:20', '12:00', '6', 'pri1', 'tuesday', 'gg1000zde', 'gg1000'),
(121, '00009', 'History', 'PF0009', 'Chinedu', '12:10', '12:50', '7', 'pri1', 'tuesday', 'gg1000zde', 'gg1000'),
(122, '00011', 'Government ', 'PF0011', 'Mary', '12:50', '13:30', '8', 'pri1', 'tuesday', 'gg1000zde', 'gg1000'),
(123, '00011', 'Government ', 'PF0011', 'Mary', '11:40', '12:10', '9', 'jss1', 'monday', 'gg1000wyz', 'gg1000');

-- --------------------------------------------------------

--
-- Table structure for table `acc_timetabling_period`
--

CREATE TABLE `acc_timetabling_period` (
  `id` int(11) NOT NULL,
  `start` varchar(5) NOT NULL,
  `end` varchar(5) NOT NULL,
  `duration` int(11) NOT NULL DEFAULT '0',
  `period_id` int(11) NOT NULL DEFAULT '0',
  `periods_bf_f_break` int(11) NOT NULL DEFAULT '0',
  `periods_bf_s_break` int(11) NOT NULL DEFAULT '0',
  `f_break` int(11) NOT NULL DEFAULT '0',
  `s_break` int(11) NOT NULL DEFAULT '0',
  `periods_per_day` int(11) NOT NULL DEFAULT '0',
  `class_id` varchar(20) NOT NULL,
  `szbranch_id` varchar(20) NOT NULL,
  `szschool_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `acc_timetabling_period`
--

INSERT INTO `acc_timetabling_period` (`id`, `start`, `end`, `duration`, `period_id`, `periods_bf_f_break`, `periods_bf_s_break`, `f_break`, `s_break`, `periods_per_day`, `class_id`, `szbranch_id`, `szschool_id`) VALUES
(7, '7:30', '13:30', 40, 0, 3, 3, 30, 10, 8, 'pri1', 'gg1000zde', 'gg1000'),
(9, '7:0', '12:10', 30, 0, 4, 3, 30, 10, 9, 'jss1', 'gg1000wyz', 'gg1000'),
(12, '7:30', '13:30', 40, 0, 3, 3, 30, 10, 8, 'SHS', 'GG100WYZ', 'GG100'),
(13, '', '0:0', 0, 0, 0, 0, 0, 0, 0, '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `acc_subjects`
--
ALTER TABLE `acc_subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `acc_timetable`
--
ALTER TABLE `acc_timetable`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `acc_timetabling_period`
--
ALTER TABLE `acc_timetabling_period`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `acc_subjects`
--
ALTER TABLE `acc_subjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `acc_timetable`
--
ALTER TABLE `acc_timetable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=124;
--
-- AUTO_INCREMENT for table `acc_timetabling_period`
--
ALTER TABLE `acc_timetabling_period`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
